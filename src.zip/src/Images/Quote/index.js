export const QuoteImage = (
  <svg
    width="38"
    height="22"
    viewBox="0 0 38 22"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M10.096 21.88H0.304L9.52 0.0879974H15.76L10.096 21.88ZM27.736 0.0879974H37.432L28.216 21.88H22.072L27.736 0.0879974Z"
      fill="black"
    />
  </svg>
);
